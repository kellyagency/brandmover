import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        forest: { DEFAULT: "#0E2B20", 700: "#14402F", 500: "#1F6B4B", 100: "#DCEBE2", 50: "#F1F6F3" },
        cloth: { DEFAULT: "#C9962B", 100: "#F6E8C6" },
        flag: "#C8312B",
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};
export default config;
