# BrandMover AI

Next.js 14 (App Router) + Tailwind + Prisma/Supabase + Paystack.

## Run
1. `cp .env.example .env` and fill in keys (Paystack: dashboard.paystack.com > Settings > API Keys; Supabase: Project Settings > Database).
2. `npm install`
3. `npx prisma db push`
4. `npm run dev` then open http://localhost:3000

## Deploy to Vercel
Push to GitHub, import the repo in Vercel, add the same env vars, deploy.
In Paystack, set the webhook URL to `https://YOUR-DOMAIN/api/paystack/webhook`.

## Status
Built: landing page, dashboard overview, lead table (sample data), Paystack pay page + webhook, Prisma schema.
Next: Google Places lead finder (Step 2), outreach approval, contracts/invoices, builder, social agent.
Dashboard and lead table show sample data until the lead finder is connected.
