"use client";
import { useMemo, useState } from "react";

type Lead = { id: number; name: string; city: string; country: "GH" | "US"; category: string; phone: string; rating: number; reviews: number; need: "website" | "social_media" | "both"; score: number; status: string };

const DATA: Lead[] = [
  { id: 1, name: "Kofi's Cuts", city: "Accra", country: "GH", category: "Barbershop", phone: "+233 24 000 0001", rating: 4.2, reviews: 14, need: "both", score: 92, status: "lead_found" },
  { id: 2, name: "Adwoa Roofing Works", city: "Kumasi", country: "GH", category: "Roofing", phone: "+233 20 000 0002", rating: 4.6, reviews: 38, need: "website", score: 81, status: "outreach_sent" },
  { id: 3, name: "Osu Grill House", city: "Accra", country: "GH", category: "Restaurant", phone: "+233 55 000 0003", rating: 3.7, reviews: 9, need: "social_media", score: 77, status: "lead_found" },
  { id: 4, name: "Lone Star Roofing", city: "Houston", country: "US", category: "Roofing", phone: "+1 713 555 0104", rating: 4.8, reviews: 61, need: "website", score: 70, status: "replied_interested" },
  { id: 5, name: "Glow Studio Salon", city: "Tema", country: "GH", category: "Salon", phone: "+233 27 000 0005", rating: 3.9, reviews: 11, need: "both", score: 88, status: "call_booked" },
];

const need: Record<Lead["need"], string> = { website: "No website", social_media: "Weak social", both: "Both" };

export default function LeadTable() {
  const [q, setQ] = useState(""); const [country, setCountry] = useState("all"); const [n, setN] = useState("all");
  const rows = useMemo(() => DATA.filter((l) =>
    (country === "all" || l.country === country) && (n === "all" || l.need === n) &&
    (l.name + l.category + l.city).toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.score - a.score), [q, country, n]);
  const sel = "rounded-lg border border-forest/15 bg-white px-3 py-2 text-sm";
  return (
    <div>
      <div className="flex flex-wrap gap-3">
        <input aria-label="Search leads" placeholder="Search name, category, city" value={q} onChange={(e) => setQ(e.target.value)} className={`${sel} w-64`} />
        <select aria-label="Country" value={country} onChange={(e) => setCountry(e.target.value)} className={sel}><option value="all">Ghana and US</option><option value="GH">Ghana</option><option value="US">United States</option></select>
        <select aria-label="Need" value={n} onChange={(e) => setN(e.target.value)} className={sel}><option value="all">All needs</option><option value="website">No website</option><option value="social_media">Weak social</option><option value="both">Both</option></select>
      </div>
      <div className="mt-5 overflow-x-auto rounded-xl bg-white">
        <table className="w-full min-w-[760px] text-left text-sm">
          <thead className="border-b border-forest/10 text-forest/60"><tr>{["Business", "Category", "Rating", "Need", "Score", "Status", ""].map((h) => <th key={h} className="px-4 py-3 font-medium">{h}</th>)}</tr></thead>
          <tbody>
            {rows.map((l) => (
              <tr key={l.id} className="border-b border-forest/5 last:border-0">
                <td className="px-4 py-3"><p className="font-semibold">{l.name}</p><p className="text-xs text-forest/60">{l.city}, {l.country} · {l.phone}</p></td>
                <td className="px-4 py-3">{l.category}</td>
                <td className="px-4 py-3">{l.rating} <span className="text-forest/50">({l.reviews})</span></td>
                <td className="px-4 py-3"><span className="rounded-full bg-cloth-100 px-2.5 py-1 text-xs font-medium">{need[l.need]}</span></td>
                <td className="px-4 py-3 font-semibold">{l.score}</td>
                <td className="px-4 py-3 text-forest/70">{l.status.replace(/_/g, " ")}</td>
                <td className="px-4 py-3 text-right"><button className="rounded-full bg-forest px-3.5 py-1.5 text-xs font-semibold text-white hover:bg-forest-700">Draft email</button></td>
              </tr>
            ))}
            {rows.length === 0 && <tr><td colSpan={7} className="px-4 py-10 text-center text-forest/60">No leads match these filters. Clear a filter to see more.</td></tr>}
          </tbody>
        </table>
      </div>
      <p className="mt-3 text-xs text-forest/60">Contact details come only from public Google Maps listings. Nothing is sent until you approve it.</p>
    </div>
  );
}
