const nav = [
  ["Overview", "/dashboard"], ["Leads", "/dashboard/leads"], ["Outreach", "#"],
  ["Calls", "#"], ["Builder", "#"], ["Social", "#"], ["Money", "#"],
];
export default function Sidebar({ active }: { active: string }) {
  return (
    <aside className="hidden w-56 shrink-0 bg-forest text-forest-100 md:block">
      <div className="px-5 py-6 font-display text-lg font-bold text-white">BrandMover<span className="text-cloth">.ai</span></div>
      <div className="kente" />
      <nav className="mt-4 space-y-1 px-3 text-sm">
        {nav.map(([n, h]) => (
          <a key={n} href={h} className={`block rounded-md px-3 py-2 ${active === n ? "bg-forest-700 text-white" : "hover:bg-forest-700/60"}`}>{n}</a>
        ))}
      </nav>
    </aside>
  );
}
