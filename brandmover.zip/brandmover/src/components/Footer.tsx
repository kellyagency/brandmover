export default function Footer() {
  return (
    <footer className="mt-24 bg-forest text-forest-100">
      <div className="kente" />
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-6 py-10 text-sm md:flex-row md:justify-between">
        <p>© {new Date().getFullYear()} BrandMover AI. Accra, Ghana.</p>
        <nav className="flex flex-wrap gap-5">
          <a href="/terms">Terms</a><a href="/privacy">Privacy Policy</a>
          <a href="/no-spam">No Spam Policy</a><a href="/refunds">Refund Policy</a>
        </nav>
      </div>
    </footer>
  );
}
