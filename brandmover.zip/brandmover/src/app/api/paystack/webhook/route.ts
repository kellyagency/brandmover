import crypto from "crypto";
import { NextResponse } from "next/server";

export async function POST(req: Request) {
  const raw = await req.text();
  const sig = req.headers.get("x-paystack-signature") ?? "";
  const hash = crypto.createHmac("sha512", process.env.PAYSTACK_SECRET_KEY ?? "").update(raw).digest("hex");
  if (hash !== sig) return NextResponse.json({ error: "bad signature" }, { status: 401 });

  const event = JSON.parse(raw);
  if (event.event === "charge.success") {
    // TODO: save Payment (providerRef = event.data.reference), set lead status to "paid",
    // generate invoice + contract PDFs, write ConsentLog (terms_accepted, ip from metadata).
    console.log("paid", event.data.reference, event.data.metadata?.plan);
  }
  return NextResponse.json({ received: true });
}
