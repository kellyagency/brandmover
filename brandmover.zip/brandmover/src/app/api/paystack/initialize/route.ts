import { NextResponse } from "next/server";
import { PLANS } from "@/lib/plans";

const hits = new Map<string, { n: number; t: number }>(); // simple per-IP rate limit (use Upstash in production)

export async function POST(req: Request) {
  const ip = req.headers.get("x-forwarded-for") ?? "local";
  const h = hits.get(ip); const now = Date.now();
  if (h && now - h.t < 60_000 && h.n >= 5) return NextResponse.json({ error: "Too many attempts. Wait a minute and try again." }, { status: 429 });
  hits.set(ip, h && now - h.t < 60_000 ? { n: h.n + 1, t: h.t } : { n: 1, t: now });

  const { plan, email, name } = await req.json();
  const p = PLANS[plan];
  if (!p || !/^\S+@\S+\.\S+$/.test(email ?? "")) return NextResponse.json({ error: "Check your package and email, then try again." }, { status: 400 });
  if (!process.env.PAYSTACK_SECRET_KEY) return NextResponse.json({ error: "Payments are not configured yet." }, { status: 500 });

  const res = await fetch("https://api.paystack.co/transaction/initialize", {
    method: "POST",
    headers: { Authorization: `Bearer ${process.env.PAYSTACK_SECRET_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      email, currency: "GHS",
      amount: (p.ghs / 2) * 100, // 50% upfront, in pesewas
      channels: ["mobile_money", "card"],
      callback_url: `${process.env.NEXT_PUBLIC_APP_URL}/pay/success`,
      metadata: { plan: p.label, name, phase: "upfront", ip, terms_accepted: true },
    }),
  });
  const d = await res.json();
  if (!res.ok || !d.status) { console.error("paystack init failed", d); return NextResponse.json({ error: "Paystack could not start this payment." }, { status: 502 }); }
  return NextResponse.json({ url: d.data.authorization_url });
}
