import Sidebar from "@/components/Sidebar";
import LeadTable from "@/components/LeadTable";
export default function Leads() {
  return (
    <div className="flex min-h-screen">
      <Sidebar active="Leads" />
      <main className="flex-1 p-6 md:p-10">
        <h1 className="font-display text-3xl font-bold">Leads</h1>
        <p className="mb-6 mt-1 text-forest/70">Businesses with no website or a struggling social presence, best fit first.</p>
        <LeadTable />
      </main>
    </div>
  );
}
