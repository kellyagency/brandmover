import Sidebar from "@/components/Sidebar";

const stats = [
  { l: "Leads found", v: "248", s: "Accra, Kumasi, Houston" },
  { l: "Awaiting your approval", v: "12", s: "Emails drafted, none sent" },
  { l: "Calls booked", v: "3", s: "Next: Tue 10:30" },
  { l: "Revenue this month", v: "GH₵ 7,500", s: "2 paid, 1 pending" },
];
const pipeline = [["Lead found", 142], ["Outreach sent", 61], ["Interested", 18], ["Call booked", 7], ["Proposal sent", 4], ["Paid", 2]] as const;

export default function Dashboard() {
  return (
    <div className="flex min-h-screen">
      <Sidebar active="Overview" />
      <main className="flex-1 p-6 md:p-10">
        <h1 className="font-display text-3xl font-bold">Good morning</h1>
        <p className="mt-1 text-forest/70">Sample data shown. Connect Supabase to see your own.</p>
        <div className="mt-8 grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          {stats.map((s) => (
            <div key={s.l} className="rounded-xl bg-white p-5">
              <p className="text-sm text-forest/70">{s.l}</p>
              <p className="mt-2 font-display text-3xl font-bold">{s.v}</p>
              <p className="mt-1 text-xs text-forest/60">{s.s}</p>
            </div>
          ))}
        </div>
        <section className="mt-8 rounded-xl bg-white p-6">
          <h2 className="font-display text-lg font-bold">Pipeline</h2>
          <div className="mt-5 space-y-3">
            {pipeline.map(([n, c]) => (
              <div key={n} className="flex items-center gap-4 text-sm">
                <span className="w-32 shrink-0">{n}</span>
                <div className="h-3 flex-1 rounded-full bg-forest-50"><div className="h-3 rounded-full bg-cloth" style={{ width: `${(c / 142) * 100}%` }} /></div>
                <span className="w-8 text-right font-semibold">{c}</span>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}
