"use client";
import { useState } from "react";
import { PLANS } from "@/lib/plans";

export default function Pay() {
  const params = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : null;
  const [plan, setPlan] = useState(params?.get("plan") && PLANS[params.get("plan")!] ? params.get("plan")! : "business");
  const [email, setEmail] = useState(""); const [name, setName] = useState("");
  const [agree, setAgree] = useState(false); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  const total = PLANS[plan].ghs; const deposit = total / 2;

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setErr("");
    try {
      const r = await fetch("/api/paystack/initialize", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ plan, email, name }) });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Payment could not start");
      window.location.href = d.url;
    } catch (x: any) { setErr(x.message); setBusy(false); }
  }
  const field = "mt-1 w-full rounded-lg border border-forest/20 bg-white px-4 py-3";
  return (
    <main className="mx-auto grid min-h-screen max-w-4xl gap-8 px-6 py-12 md:grid-cols-2">
      <div>
        <a href="/" className="font-display text-xl font-bold">BrandMover<span className="text-cloth">.ai</span></a>
        <div className="kente mt-4" />
        <h1 className="mt-8 font-display text-3xl font-bold">Start your project</h1>
        <p className="mt-2 text-forest/75">Pay half now to begin. Pay the rest when you approve your preview.</p>
        <dl className="mt-8 space-y-3 rounded-xl bg-white p-5 text-sm">
          <div className="flex justify-between"><dt>{PLANS[plan].label}</dt><dd>GH₵ {total.toLocaleString()}</dd></div>
          <div className="flex justify-between border-t border-forest/10 pt-3 text-base font-bold"><dt>Due today (50%)</dt><dd>GH₵ {deposit.toLocaleString()}</dd></div>
        </dl>
        <p className="mt-4 text-xs text-forest/60">Includes 2 revisions. Website in 7 days, social plan in 30 days. No refund after you approve your preview.</p>
      </div>
      <form onSubmit={submit} className="space-y-4 rounded-2xl bg-white p-6">
        <label className="block text-sm font-medium">Package
          <select value={plan} onChange={(e) => setPlan(e.target.value)} className={field}>
            {["Starter Site", "Business Site", "Social Growth", "Website + Social"].map((p) => <option key={p}>{p}</option>)}
          </select></label>
        <label className="block text-sm font-medium">Your name<input required value={name} onChange={(e) => setName(e.target.value)} className={field} /></label>
        <label className="block text-sm font-medium">Email for your receipt<input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} className={field} /></label>
        <label className="flex items-start gap-3 text-sm"><input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} className="mt-1" />
          <span>I have read and agree to the <a className="underline" href="/terms">Terms</a> and <a className="underline" href="/refunds">Refund Policy</a>.</span></label>
        {err && <p role="alert" className="rounded-lg bg-flag/10 px-4 py-3 text-sm text-flag">{err}</p>}
        <button disabled={!agree || busy} className="w-full rounded-full bg-forest py-3.5 font-semibold text-white disabled:opacity-50">{busy ? "Opening Paystack..." : `Pay GH₵ ${deposit.toLocaleString()} with MoMo or card`}</button>
      </form>
    </main>
  );
}
