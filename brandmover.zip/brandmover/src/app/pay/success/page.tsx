export default function Success() {
  return (
    <main className="mx-auto max-w-lg px-6 py-24 text-center">
      <div className="kente mb-10" />
      <h1 className="font-display text-3xl font-bold">Payment received. Akpe!</h1>
      <p className="mt-4 text-forest/75">We have emailed your receipt and contract. Your preview will be ready within 7 days.</p>
      <a href="/" className="mt-8 inline-block rounded-full bg-forest px-6 py-3 font-semibold text-white">Back to home</a>
    </main>
  );
}
