import Footer from "@/components/Footer";

const packages = [
  { name: "Starter Site", price: "GH₵1,000", note: "1–3 pages", items: ["Mobile-first design", "Google Maps and WhatsApp button", "Ready in 7 days"] },
  { name: "Business Site", price: "GH₵2,500", note: "Up to 6 pages", items: ["Booking or quote form", "Photo gallery", "2 free revisions"], featured: true },
  { name: "Social Growth", price: "GH₵2,500/mo", note: "12 posts a month", items: ["Captions and images made for you", "You approve every post", "Weekly results report"] },
  { name: "Website + Social", price: "GH₵6,000", note: "Best value bundle", items: ["Business Site + Social Growth", "Pay 50% to start, 50% at delivery", "One team, one invoice"] },
];

const steps = [
  { t: "You tell us about your business", d: "Name, services, and your logo. That's all we need." },
  { t: "We send a free preview in days", d: "See your site at a private link before you pay anything more." },
  { t: "You approve, then we launch", d: "Request up to 2 changes. Pay the second half when you're happy." },
];

export default function Home() {
  return (
    <main>
      <header className="bg-forest text-white">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
          <span className="font-display text-xl font-bold">BrandMover<span className="text-cloth">.ai</span></span>
          <nav className="flex items-center gap-6 text-sm">
            <a href="#packages" className="hidden hover:text-cloth sm:block">Packages</a>
            <a href="#how" className="hidden hover:text-cloth sm:block">How it works</a>
            <a href="/dashboard" className="rounded-full border border-white/30 px-4 py-2 hover:bg-white/10">Sign in</a>
          </nav>
        </div>
        <div className="kente" />
        <div className="mx-auto grid max-w-6xl gap-12 px-6 py-20 md:grid-cols-5 md:py-28">
          <div className="md:col-span-3">
            <h1 className="font-display text-5xl font-extrabold leading-[1.05] tracking-tight md:text-7xl">
              Customers search Google first. Be there when they do.
            </h1>
            <p className="mt-6 max-w-xl text-lg text-forest-100">
              We build your website and run your Instagram and Facebook, so you can get back to cutting hair, fixing roofs and serving food.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <a href="/pay?plan=business" className="rounded-full bg-cloth px-7 py-3.5 font-semibold text-forest hover:bg-cloth-100">Get my website</a>
              <a href="#how" className="rounded-full border border-white/30 px-7 py-3.5 font-semibold hover:bg-white/10">See how it works</a>
            </div>
          </div>
          <aside className="md:col-span-2">
            <div className="rounded-2xl bg-white p-6 text-forest shadow-xl">
              <p className="text-sm font-semibold text-forest-500">Pay the way you already do</p>
              <ul className="mt-4 space-y-3">
                {["MTN Mobile Money", "Telecel Cash", "AirtelTigo Money", "Visa and Mastercard"].map((m) => (
                  <li key={m} className="flex items-center gap-3 rounded-lg bg-forest-50 px-4 py-3 font-medium">
                    <span className="h-2.5 w-2.5 rounded-full bg-cloth" />{m}
                  </li>
                ))}
              </ul>
              <p className="mt-4 text-xs text-forest/70">Secured by Paystack. 50% to start, 50% before delivery.</p>
            </div>
          </aside>
        </div>
      </header>

      <section id="how" className="mx-auto max-w-6xl px-6 pt-24">
        <h2 className="font-display text-3xl font-bold md:text-4xl">From first message to live site in 7 days</h2>
        <ol className="mt-10 grid gap-6 md:grid-cols-3">
          {steps.map((s, i) => (
            <li key={s.t} className="border-t-4 border-cloth bg-white p-6">
              <span className="font-display text-sm font-bold text-forest-500">Step {i + 1}</span>
              <h3 className="mt-2 text-lg font-semibold">{s.t}</h3>
              <p className="mt-2 text-forest/75">{s.d}</p>
            </li>
          ))}
        </ol>
      </section>

      <section id="packages" className="mx-auto max-w-6xl px-6 pt-24">
        <h2 className="font-display text-3xl font-bold md:text-4xl">Simple prices in cedis</h2>
        <p className="mt-3 max-w-xl text-forest/75">Larger sites and higher posting volumes start from GH₵5,000. We'll quote after a short chat.</p>
        <div className="mt-10 grid gap-5 md:grid-cols-4">
          {packages.map((p) => (
            <div key={p.name} className={`flex flex-col rounded-xl p-6 ${p.featured ? "bg-forest text-white ring-4 ring-cloth" : "bg-white"}`}>
              <h3 className="font-display text-lg font-bold">{p.name}</h3>
              <p className="mt-3 text-3xl font-extrabold">{p.price}</p>
              <p className={`text-sm ${p.featured ? "text-forest-100" : "text-forest/60"}`}>{p.note}</p>
              <ul className="mt-5 flex-1 space-y-2 text-sm">{p.items.map((i) => <li key={i}>{i}</li>)}</ul>
              <a href={`/pay?plan=${encodeURIComponent(p.name)}`} className={`mt-6 rounded-full px-5 py-2.5 text-center text-sm font-semibold ${p.featured ? "bg-cloth text-forest" : "bg-forest text-white hover:bg-forest-700"}`}>Choose {p.name}</a>
            </div>
          ))}
        </div>
      </section>
      <Footer />
    </main>
  );
}
