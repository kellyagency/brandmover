// Prices in GHS pesewas (x100). Server is the source of truth.
export const PLANS: Record<string, { label: string; ghs: number }> = {
  "Starter Site": { label: "Starter Site", ghs: 1000 },
  "business": { label: "Business Site", ghs: 2500 },
  "Business Site": { label: "Business Site", ghs: 2500 },
  "Social Growth": { label: "Social Growth (first month)", ghs: 2500 },
  "Website + Social": { label: "Website + Social bundle", ghs: 6000 },
};
