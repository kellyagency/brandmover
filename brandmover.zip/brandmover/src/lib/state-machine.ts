// Each status only permits its own actions. Never mix tasks across stages.
export type LeadStatus =
  | "lead_found" | "outreach_sent" | "replied_interested" | "call_booked"
  | "proposal_sent" | "paid" | "building_website" | "preview_ready"
  | "approved" | "delivered" | "opted_out";

export const TRANSITIONS: Record<LeadStatus, LeadStatus[]> = {
  lead_found:         ["outreach_sent", "opted_out"],
  outreach_sent:      ["replied_interested", "opted_out"],
  replied_interested: ["call_booked", "opted_out"],
  call_booked:        ["proposal_sent", "opted_out"],
  proposal_sent:      ["paid", "opted_out"],
  paid:               ["building_website"],
  building_website:   ["preview_ready"],
  preview_ready:      ["approved", "building_website"], // revision loop (max 2)
  approved:           ["delivered"],
  delivered:          [],
  opted_out:          [],
};

export const ALLOWED_ACTIONS: Record<LeadStatus, string[]> = {
  lead_found:         ["enrich_contact", "draft_email"],
  outreach_sent:      ["await_reply", "send_followup_dm"],
  replied_interested: ["send_calendly_link"],
  call_booked:        ["place_call", "generate_proposal"],
  proposal_sent:      ["create_checkout"],
  paid:               ["generate_invoice", "generate_contract", "start_build"],
  building_website:   ["generate_site"],
  preview_ready:      ["share_preview", "apply_revision", "approve"],
  approved:           ["collect_final_payment", "deploy", "export_zip", "handover"],
  delivered:          [],
  opted_out:          [],
};

export function canTransition(from: LeadStatus, to: LeadStatus) {
  return TRANSITIONS[from].includes(to);
}
